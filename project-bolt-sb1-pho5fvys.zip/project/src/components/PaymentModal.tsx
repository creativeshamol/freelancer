import React, { useState } from 'react';
import { loadStripe } from '@stripe/stripe-js';
import { X } from 'lucide-react';

interface PaymentModalProps {
  service: {
    title: string;
    price: number;
    seller: string;
    deliveryTime: string;
  };
  onClose: () => void;
}

const stripePromise = loadStripe('your_publishable_key'); // Replace with your Stripe publishable key

export function PaymentModal({ service, onClose }: PaymentModalProps) {
  const [loading, setLoading] = useState(false);

  const handlePayment = async () => {
    setLoading(true);
    try {
      const stripe = await stripePromise;
      if (!stripe) throw new Error('Stripe failed to load');

      // Here you would typically make an API call to your backend to create a payment intent
      // const response = await fetch('/api/create-payment-intent', {
      //   method: 'POST',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify({ amount: service.price * 100 }), // Stripe expects amounts in cents
      // });
      // const { clientSecret } = await response.json();

      // For demo purposes, we'll just show a success message
      alert('Payment system integration pending. This would typically process a real payment.');
    } catch (error) {
      console.error('Payment failed:', error);
      alert('Payment failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-8 max-w-md w-full relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-500 hover:text-gray-700"
        >
          <X className="h-6 w-6" />
        </button>
        
        <h2 className="text-2xl font-bold mb-6">Confirm Purchase</h2>
        
        <div className="space-y-4 mb-6">
          <div className="border-b pb-4">
            <h3 className="font-semibold text-lg">{service.title}</h3>
            <p className="text-gray-600">by {service.seller}</p>
          </div>
          
          <div className="flex justify-between">
            <span className="text-gray-600">Service Price</span>
            <span className="font-semibold">${service.price}</span>
          </div>
          
          <div className="flex justify-between">
            <span className="text-gray-600">Service Fee (10%)</span>
            <span className="font-semibold">${(service.price * 0.1).toFixed(2)}</span>
          </div>
          
          <div className="flex justify-between border-t pt-4">
            <span className="font-semibold">Total</span>
            <span className="font-bold text-lg">
              ${(service.price * 1.1).toFixed(2)}
            </span>
          </div>
          
          <div className="bg-gray-50 p-4 rounded-lg">
            <p className="text-sm text-gray-600">
              Delivery Time: {service.deliveryTime}
            </p>
          </div>
        </div>
        
        <button
          onClick={handlePayment}
          disabled={loading}
          className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors disabled:bg-blue-300"
        >
          {loading ? 'Processing...' : 'Pay Now'}
        </button>
        
        <p className="text-sm text-gray-500 mt-4 text-center">
          Your payment is secured by Stripe. You'll only be charged once you approve the delivered work.
        </p>
      </div>
    </div>
  );
}