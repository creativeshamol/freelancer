import React, { useState } from 'react';
import { Search, Star, Clock, Shield, TrendingUp, Briefcase, MessageSquare, Heart, Filter, ChevronDown, Code2 } from 'lucide-react';
import { PaymentModal } from './components/PaymentModal';

function App() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedService, setSelectedService] = useState<any>(null);

  const categories = [
    { id: 'all', name: 'All Categories' },
    { id: 'programming', name: 'Programming & Tech' },
    { id: 'design', name: 'Design & Creative' },
    { id: 'writing', name: 'Writing & Translation' },
    { id: 'marketing', name: 'Digital Marketing' },
    { id: 'video', name: 'Video & Animation' }
  ];

  const services = [
    {
      id: 1,
      title: "Professional Website Development",
      seller: "CodeMaster",
      rating: 4.9,
      reviews: 382,
      price: 99,
      image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=800&q=80",
      category: "programming",
      deliveryTime: "3 days",
      level: "Level 2"
    },
    {
      id: 2,
      title: "Modern Logo Design",
      seller: "DesignPro",
      rating: 5.0,
      reviews: 891,
      price: 79,
      image: "https://images.unsplash.com/photo-1626785774573-4b799315345d?auto=format&fit=crop&w=800&q=80",
      category: "design",
      deliveryTime: "2 days",
      level: "Top Rated"
    },
    {
      id: 3,
      title: "SEO Optimization",
      seller: "MarketingGuru",
      rating: 4.8,
      reviews: 245,
      price: 149,
      image: "https://images.unsplash.com/photo-1533750349088-cd871a92f312?auto=format&fit=crop&w=800&q=80",
      category: "marketing",
      deliveryTime: "5 days",
      level: "Level 1"
    },
    {
      id: 4,
      title: "Content Writing",
      seller: "WordSmith",
      rating: 4.7,
      reviews: 156,
      price: 49,
      image: "https://images.unsplash.com/photo-1455390582262-044cdead277a?auto=format&fit=crop&w=800&q=80",
      category: "writing",
      deliveryTime: "1 day",
      level: "Level 2"
    },
    {
      id: 5,
      title: "Video Editing",
      seller: "VisualArtist",
      rating: 4.9,
      reviews: 423,
      price: 199,
      image: "https://images.unsplash.com/photo-1536240478700-b869070f9279?auto=format&fit=crop&w=800&q=80",
      category: "video",
      deliveryTime: "4 days",
      level: "Top Rated"
    },
    {
      id: 6,
      title: "Mobile App Development",
      seller: "AppWizard",
      rating: 4.8,
      reviews: 317,
      price: 299,
      image: "https://images.unsplash.com/photo-1555774698-0b77e0d5fac6?auto=format&fit=crop&w=800&q=80",
      category: "programming",
      deliveryTime: "7 days",
      level: "Level 2"
    }
  ];

  const filteredServices = selectedCategory === 'all' 
    ? services 
    : services.filter(service => service.category === selectedCategory);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm fixed w-full z-10">
        <div className="container mx-auto">
          <div className="flex items-center justify-between py-4">
            <div className="flex items-center space-x-8">
              <div className="flex items-center space-x-2">
                <Code2 className="h-8 w-8 text-blue-600" />
                <span className="text-xl font-bold">FreelanceLife</span>
              </div>
              <div className="hidden md:flex relative flex-1 max-w-xl">
                <input
                  type="text"
                  placeholder="Search for services..."
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-full focus:outline-none focus:border-blue-500"
                />
                <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
              </div>
            </div>
            <nav className="flex items-center space-x-6">
              <a href="#" className="nav-link hidden md:block">Become a Seller</a>
              <a href="#" className="nav-link hidden md:block">Sign In</a>
              <button className="btn-primary">Join</button>
            </nav>
          </div>
        </div>
      </header>

      {/* Categories */}
      <div className="pt-20 bg-white border-b">
        <div className="container mx-auto py-4">
          <div className="flex space-x-6 overflow-x-auto pb-2">
            {categories.map(category => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`whitespace-nowrap px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                  selectedCategory === category.id
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category.name}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="container mx-auto py-8">
        {/* Filters */}
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center space-x-4">
            <button className="flex items-center space-x-2 px-4 py-2 border rounded-full hover:bg-gray-50">
              <Filter className="h-4 w-4" />
              <span>Filters</span>
            </button>
            <button className="flex items-center space-x-2 px-4 py-2 border rounded-full hover:bg-gray-50">
              <Clock className="h-4 w-4" />
              <span>Delivery Time</span>
              <ChevronDown className="h-4 w-4" />
            </button>
            <button className="flex items-center space-x-2 px-4 py-2 border rounded-full hover:bg-gray-50">
              <Star className="h-4 w-4" />
              <span>Rating</span>
              <ChevronDown className="h-4 w-4" />
            </button>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-gray-600">Sort by:</span>
            <select className="border rounded-full px-4 py-2 bg-white">
              <option>Best Selling</option>
              <option>Newest</option>
              <option>Price: Low to High</option>
              <option>Price: High to Low</option>
            </select>
          </div>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-3 gap-8">
          {filteredServices.map(service => (
            <div key={service.id} className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow">
              <div className="relative">
                <img 
                  src={service.image} 
                  alt={service.title}
                  className="w-full h-48 object-cover rounded-t-lg"
                />
                <button className="absolute top-4 right-4 p-2 bg-white rounded-full shadow-sm hover:bg-gray-100">
                  <Heart className="h-5 w-5 text-gray-600" />
                </button>
              </div>
              <div className="p-6">
                <div className="flex items-center space-x-2 mb-2">
                  <img
                    src={`https://ui-avatars.com/api/?name=${service.seller}&background=random`}
                    alt={service.seller}
                    className="w-8 h-8 rounded-full"
                  />
                  <span className="font-medium">{service.seller}</span>
                  <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">
                    {service.level}
                  </span>
                </div>
                <h3 className="text-lg font-semibold mb-2 hover:text-blue-600 cursor-pointer">
                  {service.title}
                </h3>
                <div className="flex items-center text-yellow-400 mb-4">
                  <Star className="h-4 w-4 fill-current" />
                  <span className="ml-1 text-sm">{service.rating}</span>
                  <span className="ml-1 text-sm text-gray-500">({service.reviews})</span>
                </div>
                <div className="flex items-center justify-between pt-4 border-t">
                  <div className="flex items-center space-x-2 text-gray-500">
                    <Clock className="h-4 w-4" />
                    <span className="text-sm">{service.deliveryTime}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-xs text-gray-500">Starting at</span>
                    <p className="text-lg font-bold">${service.price}</p>
                  </div>
                </div>
                <button
                  onClick={() => setSelectedService(service)}
                  className="w-full mt-4 bg-blue-600 text-white py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors"
                >
                  Order Now
                </button>
              </div>
            </div>
          ))}
        </div>
      </main>

      {/* Features Section */}
      <section className="bg-white py-16">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Why Choose FreelanceHub</h2>
          <div className="grid md:grid-cols-4 gap-8">
            {[
              {
                icon: <Shield className="h-8 w-8 text-blue-600" />,
                title: "Secure Payments",
                description: "Your payment is protected until you're satisfied with the work"
              },
              {
                icon: <TrendingUp className="h-8 w-8 text-blue-600" />,
                title: "Quality Work",
                description: "Access top talent and professional services"
              },
              {
                icon: <Briefcase className="h-8 w-8 text-blue-600" />,
                title: "Diverse Services",
                description: "Find the perfect service for your needs"
              },
              {
                icon: <MessageSquare className="h-8 w-8 text-blue-600" />,
                title: "24/7 Support",
                description: "Get help whenever you need it"
              }
            ].map((feature, index) => (
              <div key={index} className="text-center">
                <div className="flex justify-center mb-4">{feature.icon}</div>
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Code2 className="h-6 w-6 text-blue-400" />
                <span className="text-lg font-bold">FreelanceHub</span>
              </div>
              <p className="text-gray-400">
                Connect with skilled freelancers and get your projects done.
              </p>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Categories</h4>
              <ul className="space-y-2">
                <li><a href="#" className="footer-link">Programming & Tech</a></li>
                <li><a href="#" className="footer-link">Design & Creative</a></li>
                <li><a href="#" className="footer-link">Writing & Translation</a></li>
                <li><a href="#" className="footer-link">Digital Marketing</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">About</h4>
              <ul className="space-y-2">
                <li><a href="#" className="footer-link">How it Works</a></li>
                <li><a href="#" className="footer-link">Success Stories</a></li>
                <li><a href="#" className="footer-link">Terms of Service</a></li>
                <li><a href="#" className="footer-link">Privacy Policy</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Support</h4>
              <ul className="space-y-2">
                <li><a href="#" className="footer-link">Help & Support</a></li>
                <li><a href="#" className="footer-link">Trust & Safety</a></li>
                <li><a href="#" className="footer-link">Selling on FreelanceHub</a></li>
                <li><a href="#" className="footer-link">Buying on FreelanceHub</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>© 2024 FreelanceHub. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* Payment Modal */}
      {selectedService && (
        <PaymentModal
          service={selectedService}
          onClose={() => setSelectedService(null)}
        />
      )}
    </div>
  );
}

export default App;